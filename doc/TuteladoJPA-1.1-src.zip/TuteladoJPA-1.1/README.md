# Traballo tutelado O/RM

> Juan Toirán Freire \<juan.tfreire@udc.es\>

> Iker García Calviño \<iker.gcalvino@udc.es\>

## Diagrama de clases

![Diagrama de clases](/doc/diagrama.png)

## Relación de eleccións realizadas

![Relación de eleccións realizadas](/doc/eleccions.png)

## Relación de métodos implementados

![Relación de métodos implementados](/doc/metodos.png)

## Relación de tests implementados

![Relación de tests implementados](/doc/tests.png)
